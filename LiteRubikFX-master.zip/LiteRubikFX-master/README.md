LiteRubikFX
===========

A JavaFX based application for playing with a 3D model of the Rubik's Cube by rotating 
layers or the whole cube

Explained here: http://jperedadnr.blogspot.com.es/2014/04/rubikfx-solving-rubiks-cube-with-javafx.html

Requires Java 8: http://www.oracle.com/technetwork/java/javase/downloads/jdk8-downloads-2133151.html

Requires 3DViewer from OpenJFX. It can be download it from here: 
http://hg.openjdk.java.net/openjfx/8/master/rt/file/f89b7dc932af/apps/experiments/3DViewer
 
José Pereda - April 2014 - https://twitter.com/JPeredaDnr